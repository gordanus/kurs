$(document).ready(function(){

    $('body').css('background-color','burlywood');
    $('body').css('font-family','tahoma');

    $('form').addClass('stilForme');

    $('#sakrij').click(function(){
        $('#kontakt').hide(1500);
    });

    $('#slika').prepend('<img src="ns.jpg">');

    $('#prikazi').click(function(){
        $('#kontakt').toggle(1500);
    })




});