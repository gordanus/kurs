function racunaj(prviBroj, drugiBroj) {
    var treciBroj = 5;
    var rezultat;
    rezultat = (prviBroj + drugiBroj) * treciBroj;
    return rezultat;
}

var broj = racunaj(4, 6);
console.log('Rezultat je ' + broj);


var prozor;
function otvori() {
    prozor = window.open('reklama.html', '_blank', 'width=320,height=250');
    setTimeout('zatvori()', 6000);
}

function zatvori() {
    prozor.close();
}

function provera() {
    var ime = document.getElementById('ime').value;

    if (ime === "") {
        document.getElementById('poruka').innerHTML = "Niste uneli vrednost";
    }
}

function pozadina() {
    document.getElementsByTagName('body')[0].setAttribute('style','background-color: blanchedalmond');
}

function sat() {
    var danas = new Date;
    var sati = danas.getHours();
    var minuti = danas.getMinutes();
    var sekunde = danas.getSeconds();

    var vreme = sati + ":" + minuti + ":" + sekunde;
    document.getElementById("sat").innerHTML = vreme;
}

// funkcija za pomeranje sata svake sekunde
setInterval(sat,1000);

function stampanje() {
    var inputs = document.getElementsByTagName('input');
    for (i = 0; i < inputs.length; i++) {
        // dodatna If provera koja loguje samo inpute koji imaju type='text'
        if (inputs[i].type === "text") {
            console.log(inputs[i].value);
        }
    }
}